#!/usr/bin/env python

# Create OpenSearch Domain Snapshot
# https://docs.aws.amazon.com/opensearch-service/latest/developerguide/managedomains-snapshots.html

