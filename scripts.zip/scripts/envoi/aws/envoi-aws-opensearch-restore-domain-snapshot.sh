#!/usr/bin/env python

# # Restore OpenSearch Domain Snapshot
# envoi-cloud-infrastructure aws es create-elasticsearch-domain | backup-elasticsearch-domain | restore-elasticsearch-domain
# https://awscli.amazonaws.com/v2/documentation/api/latest/reference/es/create-elasticsearch-domain.html